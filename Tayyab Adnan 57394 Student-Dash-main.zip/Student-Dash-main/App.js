import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  RefreshControl,
  TextInput,
  TouchableOpacity,
} from 'react-native';

// Dashboard header component to display student information
const DashboardHeader = ({ students, themeStyles }) => (
  <View style={[baseStyles.header, themeStyles.header]}>
    {students.length > 0 ? (
      <>
        <Text style={[baseStyles.heading, themeStyles.text]}>Student Dashboard</Text>
        <Text style={[baseStyles.studentCount, themeStyles.text]}>
          Total Students: {students.length}
        </Text>
      </>
    ) : (
      <Text style={[baseStyles.loading, themeStyles.text]}>Loading...</Text>
    )}
  </View>
);

const App = () => {
  const [students, setStudents] = useState([]);
  const [filteredStudents, setFilteredStudents] = useState([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(false); // State for dark mode

  const themeStyles = isDarkMode ? darkThemeStyles : lightThemeStyles;

  const mockApi = 'https://mocki.io/v1/06c70354-8db3-438a-83f0-b57277310b57';

  const fetchStudents = async () => {
    try {
      setIsRefreshing(true);
      const response = await fetch(mockApi);
      const data = await response.json();

      if (Array.isArray(data)) {
        setStudents(data);
        setFilteredStudents(data);
      } else if (data.students && Array.isArray(data.students)) {
        setStudents(data.students);
        setFilteredStudents(data.students);
      } else {
        console.log('Unexpected data structure:', data);
      }

      setIsRefreshing(false);
    } catch (error) {
      console.error('Error fetching student data:', error);
      setIsRefreshing(false);
    }
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
    if (query.trim() === '') {
      setFilteredStudents(students);
    } else {
      const filtered = students.filter((student) =>
        student.name.toLowerCase().includes(query.toLowerCase()) ||
        student.courses.some((course) =>
          course.toLowerCase().includes(query.toLowerCase())
        )
      );
      setFilteredStudents(filtered);
    }
  };

  const toggleDarkMode = () => setIsDarkMode((prevMode) => !prevMode); // Toggle dark mode

  useEffect(() => {
    fetchStudents();
  }, []);

  return (
    <View style={[baseStyles.container, themeStyles.container]}>
      {/* Toggle Button */}
      <TouchableOpacity
        onPress={toggleDarkMode}
        style={[baseStyles.toggleButton, themeStyles.button]}
      >
        <Text style={[baseStyles.buttonText, themeStyles.text]}>
          {isDarkMode ? 'Disable Dark Mode' : 'Enable Dark Mode'}
        </Text>
      </TouchableOpacity>

      <FlatList
        data={filteredStudents}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={[baseStyles.card, themeStyles.card]}>
            <Text style={[baseStyles.cardTitle, themeStyles.text]}>{item.name}</Text>
            <Text style={[baseStyles.cardInfo, themeStyles.text]}>ID: {item.id}</Text>

            <Text style={[baseStyles.subHeading, themeStyles.text]}>Courses:</Text>
            {item.courses.map((course, index) => (
              <Text key={index} style={[baseStyles.courseItem, themeStyles.text]}>
                {course}
              </Text>
            ))}
          </View>
        )}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={fetchStudents}
            tintColor={isDarkMode ? '#fff' : '#000'}
          />
        }
        initialNumToRender={20}
        maxToRenderPerBatch={20}
        windowSize={21}
        ListHeaderComponent={
          <View>
            <DashboardHeader
              students={filteredStudents}
              themeStyles={themeStyles}
            />
            {/* Search Bar */}
            <TextInput
              style={[baseStyles.searchInput, themeStyles.input]}
              placeholder="Search by name or course"
              placeholderTextColor={isDarkMode ? '#aaa' : '#666'}
              value={searchQuery}
              onChangeText={handleSearch}
            />
          </View>
        }
      />
    </View>
  );
};

const baseStyles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  toggleButton: {
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 0,
    marginTop: 30,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  header: {
    paddingVertical: 20,
    paddingHorizontal: 15,
    borderRadius: 10,
    marginBottom: 30,
    marginTop: 30,
  },
  heading: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  studentCount: {
    fontSize: 18,
    fontStyle: 'italic',
  },
  loading: {
    fontSize: 18,
    textAlign: 'center',
    marginTop: 50,
  },
  card: {
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
    marginHorizontal: 10,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: 'bold',
  },
  cardInfo: {
    fontSize: 16,
    marginBottom: 10,
  },
  subHeading: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 10,
    marginBottom: 5,
  },
  courseItem: {
    fontSize: 16,
    paddingVertical: 4,
  },
  searchInput: {
    borderWidth: 1,
    padding: 10,
    marginBottom: 30,
    borderRadius: 8,
    fontSize: 16,
  },
});

const lightThemeStyles = StyleSheet.create({
  container: {
    backgroundColor: '#f7f9fc',
  },
  input: {
    borderColor: '#ccc',
    backgroundColor: '#fff',
  },
  card: {
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    elevation: 3,
  },
  text: {
    color: '#333',
  },
  header: {
    backgroundColor: '#4c8bf5',
  },
  button: {
    backgroundColor: '#4c8bf5',
  },
});

const darkThemeStyles = StyleSheet.create({
  container: {
    backgroundColor: '#121212',
  },
  input: {
    borderColor: '#444',
    backgroundColor: '#222',
  },
  card: {
    backgroundColor: '#1e1e1e',
    shadowColor: '#000',
    shadowOpacity: 0.7,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 6,
    elevation: 5,
  },
  text: {
    color: '#ddd',
  },
  header: {
    backgroundColor: '#333',
  },
  button: {
    backgroundColor: '#555',
  },
});

export default App;

